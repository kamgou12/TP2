## CONSTRUCTION D'UNE IMAGE 

# Date : 18 septembre 2024

### Description du projet 
Demonstration d'une image personliser

## Section1 etape2. 


# Image Dupral personaliser;


![Dupral](TP2\images\pDrupalperso.PNG)

S
